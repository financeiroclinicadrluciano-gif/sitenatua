import Header from "@/components/natua/Header";
import Hero from "@/components/natua/Hero";
import Diagnostico from "@/components/natua/Diagnostico";
import ParaQuem from "@/components/natua/ParaQuem";
import Metodologia from "@/components/natua/Metodologia";
import Experiencia from "@/components/natua/Experiencia";
import CtaFinal from "@/components/natua/CtaFinal";
import Footer from "@/components/natua/Footer";

const Index = () => {
  return (
    <>
      <Header />
      <main>
        <Hero />
        <Diagnostico />
        <ParaQuem />
        <Metodologia />
        <Experiencia />
        <CtaFinal />
      </main>
      <Footer />
    </>
  );
};

export default Index;
