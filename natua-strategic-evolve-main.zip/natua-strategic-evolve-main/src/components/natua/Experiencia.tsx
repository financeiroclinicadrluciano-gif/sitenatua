import { motion } from "framer-motion";
import { WHATSAPP_LINK } from "@/lib/constants";

const fadeUp = {
  hidden: { opacity: 0, y: 30 },
  visible: (i: number) => ({
    opacity: 1,
    y: 0,
    transition: { duration: 0.6, delay: i * 0.15 },
  }),
};

const Experiencia = () => {
  return (
    <section id="experiencia" className="bg-natua-cream-dark py-24 lg:py-32">
      <div className="container mx-auto px-6 lg:px-12">
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-100px" }}
          className="mx-auto max-w-3xl text-center"
        >
          <motion.h2
            variants={fadeUp}
            custom={0}
            className="font-serif text-3xl font-medium text-primary md:text-4xl lg:text-5xl"
          >
            Discrição. Sofisticação. Precisão.
          </motion.h2>
          <motion.p
            variants={fadeUp}
            custom={1}
            className="mt-8 font-sans text-base font-light leading-relaxed text-muted-foreground"
          >
            O espaço Natua foi concebido para oferecer conforto, privacidade e excelência.
          </motion.p>
          <motion.div
            variants={fadeUp}
            custom={2}
            className="mx-auto mt-8 max-w-lg space-y-3"
          >
            <p className="font-sans text-sm font-light text-muted-foreground">Equipamentos de última geração.</p>
            <p className="font-sans text-sm font-light text-muted-foreground">Ambiente exclusivo.</p>
            <p className="font-sans text-sm font-light text-muted-foreground">Atendimento individualizado.</p>
          </motion.div>
          <motion.p
            variants={fadeUp}
            custom={3}
            className="mt-8 font-serif text-base italic text-natua-green-light"
          >
            Localizado em uma das regiões mais privilegiadas de Curitiba.
          </motion.p>
          <motion.p
            variants={fadeUp}
            custom={4}
            className="mt-4 font-sans text-sm font-light text-muted-foreground"
          >
            Aqui, cada detalhe é intencional.
          </motion.p>
          <motion.div
            variants={fadeUp}
            custom={5}
            className="mt-12"
          >
            <a
              href={WHATSAPP_LINK}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-block border-2 border-natua-gold bg-transparent px-8 py-4 text-xs font-bold tracking-[0.3em] uppercase text-natua-gold transition-all hover:bg-natua-gold hover:text-natua-green-deep"
            >
              Solicitar Informações
            </a>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
};

export default Experiencia;
