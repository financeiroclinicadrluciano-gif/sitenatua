import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { Menu, X } from "lucide-react";
import { WHATSAPP_LINK } from "@/lib/constants";

const navLinks = [
  { label: "Diagnóstico", href: "#diagnostico" },
  { label: "Para Quem", href: "#para-quem" },
  { label: "Metodologia", href: "#metodologia" },
  { label: "Experiência", href: "#experiencia" },
];

const Header = () => {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 50);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <motion.header
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      transition={{ duration: 0.6 }}
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
        scrolled
          ? "bg-natua-green-deep/95 backdrop-blur-md shadow-lg"
          : "bg-transparent"
      }`}
    >
      <div className="container mx-auto flex items-center justify-between px-6 py-4 lg:px-12">
        <a href="#hero" className="font-serif text-2xl font-bold tracking-[0.3em] text-natua-cream">
          NATUA
        </a>

        {/* Desktop nav */}
        <nav className="hidden items-center gap-8 md:flex">
          {navLinks.map((link) => (
            <a
              key={link.href}
              href={link.href}
              className="text-sm font-light tracking-widest uppercase text-natua-cream/80 transition-colors hover:text-natua-gold"
            >
              {link.label}
            </a>
          ))}
          <a
            href={WHATSAPP_LINK}
            target="_blank"
            rel="noopener noreferrer"
            className="ml-4 border border-natua-gold px-5 py-2 text-xs font-bold tracking-widest uppercase text-natua-gold transition-all hover:bg-natua-gold hover:text-natua-green-deep"
          >
            Agendar
          </a>
        </nav>

        {/* Mobile toggle */}
        <button
          onClick={() => setMenuOpen(!menuOpen)}
          className="text-natua-cream md:hidden"
          aria-label="Menu"
        >
          {menuOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      {/* Mobile menu */}
      {menuOpen && (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-natua-green-deep/95 backdrop-blur-md px-6 pb-6 md:hidden"
        >
          {navLinks.map((link) => (
            <a
              key={link.href}
              href={link.href}
              onClick={() => setMenuOpen(false)}
              className="block py-3 text-sm tracking-widest uppercase text-natua-cream/80 hover:text-natua-gold"
            >
              {link.label}
            </a>
          ))}
          <a
            href={WHATSAPP_LINK}
            target="_blank"
            rel="noopener noreferrer"
            className="mt-3 inline-block border border-natua-gold px-5 py-2 text-xs font-bold tracking-widest uppercase text-natua-gold"
          >
            Agendar
          </a>
        </motion.div>
      )}
    </motion.header>
  );
};

export default Header;
