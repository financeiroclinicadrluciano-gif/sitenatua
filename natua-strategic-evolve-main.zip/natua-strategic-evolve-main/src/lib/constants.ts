export const WHATSAPP_LINK = "https://wa.me/5541999999999?text=Olá,%20gostaria%20de%20saber%20mais%20sobre%20a%20Natua.";
