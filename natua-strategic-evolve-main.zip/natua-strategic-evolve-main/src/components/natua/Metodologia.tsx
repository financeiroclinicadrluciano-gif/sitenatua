import { motion } from "framer-motion";
import { Microscope, Cpu, UsersRound } from "lucide-react";
import { WHATSAPP_LINK } from "@/lib/constants";

const pillars = [
  {
    icon: Microscope,
    title: "Medicina de Precisão",
    desc: "Intervenções baseadas em biomarcadores, epigenética e fisiologia individual.",
  },
  {
    icon: Cpu,
    title: "Tecnologia Aplicada",
    desc: "Inteligência artificial, analytics de saúde, monitoramento contínuo e ajustes milimétricos.",
  },
  {
    icon: UsersRound,
    title: "Equipe Multidisciplinar Integrada",
    desc: "Médicos, nutricionistas, especialistas em performance e terapeutas atuando sob uma única estratégia clínica.",
  },
];

const fadeUp = {
  hidden: { opacity: 0, y: 30 },
  visible: (i: number) => ({
    opacity: 1,
    y: 0,
    transition: { duration: 0.6, delay: i * 0.15 },
  }),
};

const Metodologia = () => {
  return (
    <section id="metodologia" className="bg-natua-offwhite py-24 lg:py-32">
      <div className="container mx-auto px-6 lg:px-12">
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-100px" }}
          className="mx-auto max-w-3xl text-center"
        >
          <motion.h2
            variants={fadeUp}
            custom={0}
            className="font-serif text-3xl font-medium text-primary md:text-4xl lg:text-5xl"
          >
            Metodologia Exclusiva Natua
          </motion.h2>
          <motion.p
            variants={fadeUp}
            custom={1}
            className="mt-4 font-sans text-xs font-bold tracking-[0.4em] uppercase text-natua-gold"
          >
            Ciência. Tecnologia. Integração Humana.
          </motion.p>
          <motion.p
            variants={fadeUp}
            custom={2}
            className="mt-6 font-serif text-base italic text-muted-foreground"
          >
            Não oferecemos tratamentos isolados. Oferecemos um ecossistema clínico estratégico.
          </motion.p>
        </motion.div>

        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-50px" }}
          className="mx-auto mt-16 grid max-w-5xl gap-8 md:grid-cols-3"
        >
          {pillars.map((p, i) => (
            <motion.div
              key={p.title}
              variants={fadeUp}
              custom={i + 3}
              className="text-center"
            >
              <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full border border-natua-gold/30 bg-natua-cream-dark">
                <p.icon className="h-7 w-7 text-natua-gold" strokeWidth={1.5} />
              </div>
              <h3 className="mt-6 font-serif text-xl font-medium text-primary">{p.title}</h3>
              <p className="mt-3 font-sans text-sm font-light leading-relaxed text-muted-foreground">{p.desc}</p>
            </motion.div>
          ))}
        </motion.div>

        <motion.p
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          variants={fadeUp}
          custom={6}
          className="mx-auto mt-12 max-w-xl text-center font-serif text-base italic text-natua-green-light"
        >
          O resultado é um novo padrão fisiológico sustentável.
        </motion.p>

        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          variants={fadeUp}
          custom={7}
          className="mt-10 text-center"
        >
          <a
            href={WHATSAPP_LINK}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-block border-2 border-natua-gold bg-transparent px-8 py-4 text-xs font-bold tracking-[0.3em] uppercase text-natua-gold transition-all hover:bg-natua-gold hover:text-natua-green-deep"
          >
            Conhecer o Programa Natua
          </a>
        </motion.div>
      </div>
    </section>
  );
};

export default Metodologia;
