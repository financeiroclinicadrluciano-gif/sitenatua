import { motion } from "framer-motion";
import { WHATSAPP_LINK } from "@/lib/constants";

const Hero = () => {
  return (
    <section
      id="hero"
      className="relative flex min-h-screen items-center justify-center overflow-hidden bg-natua-green-deep"
    >
      {/* Subtle gradient overlay */}
      <div className="absolute inset-0 bg-gradient-to-br from-natua-green-deep via-natua-green to-natua-green-deep opacity-80" />

      {/* Decorative gold line */}
      <div className="absolute left-1/2 top-0 h-32 w-px -translate-x-1/2 bg-gradient-to-b from-transparent to-natua-gold/30" />

      <div className="container relative z-10 mx-auto px-6 py-32 text-center lg:px-12">
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="mb-6 font-sans text-xs font-bold tracking-[0.4em] uppercase text-natua-gold"
        >
          Saúde Integrativa &amp; Longevidade
        </motion.p>

        <motion.h1
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="mx-auto max-w-4xl font-serif text-4xl font-medium leading-tight text-natua-cream md:text-5xl lg:text-6xl"
        >
          Medicina Estratégica para Quem Não Aceita Resultados Comuns
        </motion.h1>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
          className="mx-auto mt-8 max-w-2xl font-sans text-lg font-light leading-relaxed text-natua-cream/70"
        >
          A Natua é um centro de Saúde Integrativa e Longevidade de padrão internacional, dedicado a indivíduos que desejam performance física, clareza mental e composição corporal otimizada.
        </motion.p>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1, delay: 0.7 }}
          className="mx-auto mt-12 max-w-xl space-y-2"
        >
          <p className="font-serif text-base italic text-natua-gold/80 md:text-lg">
            Não tratamos sintomas. Reestruturamos o organismo.
          </p>
          <p className="font-sans text-sm font-light text-natua-cream/50">
            Transformamos dados em decisões. Decisões em performance. Performance em longevidade.
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 1 }}
          className="mt-14 flex flex-col items-center gap-4 sm:flex-row sm:justify-center"
        >
          <a
            href={WHATSAPP_LINK}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-block bg-natua-gold px-8 py-4 text-xs font-bold tracking-[0.3em] uppercase text-natua-green-deep transition-all hover:bg-natua-gold-light hover:shadow-lg"
          >
            Solicitar Avaliação Estratégica
          </a>
          <a
            href="#metodologia"
            className="inline-block border border-natua-cream/20 px-8 py-4 text-xs font-bold tracking-[0.3em] uppercase text-natua-cream/70 transition-all hover:border-natua-gold/50 hover:text-natua-gold"
          >
            Conhecer a Metodologia
          </a>
        </motion.div>
      </div>

      {/* Bottom gold line */}
      <div className="absolute bottom-0 left-1/2 h-20 w-px -translate-x-1/2 bg-gradient-to-t from-transparent to-natua-gold/20" />
    </section>
  );
};

export default Hero;
