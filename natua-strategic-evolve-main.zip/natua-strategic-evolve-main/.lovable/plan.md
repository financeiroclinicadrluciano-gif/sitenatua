

# NATUA — Landing Page Premium

Site institucional de página única para a clínica **Natua**, com estética premium inspirada em saúde integrativa e longevidade. Paleta em **verde escuro e dourado**, navegação fixa minimalista, e botões direcionando ao **WhatsApp**.

---

## Design & Identidade Visual
- **Paleta**: Verde escuro profundo (#1a2e1a), dourado (#c5a55a), creme claro (#f5f0e8), branco off-white
- **Tipografia**: Serifa elegante para títulos (estilo editorial premium), sans-serif clean para corpo de texto
- **Estilo**: Sofisticado, espaçoso, com bastante respiro visual. Seções full-width alternando fundos claros e escuros
- **Referência visual**: Inspirado na imagem de wellness spa — tons orgânicos, texturas naturais, minimalismo sofisticado

---

## Navegação Fixa (Header)
- Logo "NATUA" à esquerda em tipografia elegante
- Links de âncora para cada seção (suave scroll)
- Botão CTA "Agendar" no canto direito, direcionando ao WhatsApp
- Transparente no topo, ganha fundo ao rolar

---

## Seção 1 — Hero
- Título grande e impactante: "Medicina Estratégica para Quem Não Aceita Resultados Comuns"
- Subtexto breve sobre a missão da Natua
- Frases de impacto estilizadas ("Não tratamos sintomas. Reestruturamos o organismo.")
- Botão principal: "Solicitar Avaliação Estratégica" → WhatsApp
- Botão secundário discreto: "Conhecer a Metodologia" → scroll para seção de metodologia
- Background com gradiente verde escuro ou imagem sutil

---

## Seção 2 — Diagnóstico
- Título: "Excelência começa com precisão"
- Lista dos 5 marcadores mapeados, com ícones elegantes
- Texto sobre plano personalizado
- Botão: "Quero acesso ao diagnóstico Natua" → WhatsApp

---

## Seção 3 — Para Quem É
- Título: "Um centro para quem decide evoluir"
- Cards do público-alvo (executivos, atletas, etc.)
- 4 cards de serviços: Emagrecimento Estratégico, Longevidade Inteligente, Performance Física e Mental, Regulação do Estresse
- Cada card com ícone, título e descrição curta
- Botão: "Quero Evoluir com Estratégia" → WhatsApp

---

## Seção 4 — Metodologia
- Título: "Metodologia Exclusiva Natua"
- Subtítulo: "Ciência. Tecnologia. Integração Humana."
- 3 pilares apresentados em layout visual (Medicina de Precisão, Tecnologia Aplicada, Equipe Multidisciplinar)
- Botão: "Conhecer o Programa Natua" → WhatsApp

---

## Seção 5 — Experiência e Ambiente
- Título: "Discrição. Sofisticação. Precisão."
- Texto sobre o espaço e localização em Curitiba
- Layout limpo com bastante espaço em branco
- Botão: "Solicitar Informações" → WhatsApp

---

## Seção 6 — CTA Final (Exclusividade)
- Fundo verde escuro, texto centralizado
- "A Natua não é para todos." — texto sobre exclusividade e número limitado de membros
- Botão grande e centralizado: "Aplicar para Avaliação Estratégica" → WhatsApp
- Botão secundário: "Falar com Concierge Natua" → WhatsApp

---

## Footer
- Logo Natua, endereço em Curitiba, links de contato
- Links para WhatsApp e redes sociais
- Estilo minimalista e discreto

---

## Técnico
- Página única com smooth scroll entre seções
- Totalmente responsivo (mobile-first)
- Animações sutis de entrada ao rolar (fade-in)
- Sem necessidade de backend — apenas front-end estático

