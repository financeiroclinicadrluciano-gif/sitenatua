import { WHATSAPP_LINK } from "@/lib/constants";

const Footer = () => {
  return (
    <footer className="bg-natua-green-deep border-t border-natua-gold/10 py-12">
      <div className="container mx-auto px-6 lg:px-12">
        <div className="flex flex-col items-center gap-6 md:flex-row md:justify-between">
          <div className="text-center md:text-left">
            <p className="font-serif text-xl font-bold tracking-[0.3em] text-natua-cream">NATUA</p>
            <p className="mt-2 font-sans text-xs font-light text-natua-cream/50">
              Saúde Integrativa &amp; Longevidade
            </p>
          </div>

          <div className="text-center md:text-right">
            <p className="font-sans text-xs font-light text-natua-cream/50">
              Curitiba, PR — Brasil
            </p>
            <a
              href={WHATSAPP_LINK}
              target="_blank"
              rel="noopener noreferrer"
              className="mt-2 inline-block font-sans text-xs font-light text-natua-gold hover:text-natua-gold-light transition-colors"
            >
              Fale pelo WhatsApp
            </a>
          </div>
        </div>

        <div className="mt-8 border-t border-natua-gold/10 pt-6 text-center">
          <p className="font-sans text-[10px] font-light tracking-wider text-natua-cream/30">
            © {new Date().getFullYear()} Natua. Todos os direitos reservados.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
