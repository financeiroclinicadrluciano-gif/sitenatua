import { motion } from "framer-motion";
import { Briefcase, Dumbbell, Heart, Users, Scale, Sparkles, BrainCircuit, Battery } from "lucide-react";
import { WHATSAPP_LINK } from "@/lib/constants";

const audiences = [
  { icon: Briefcase, label: "Executivos e empresários" },
  { icon: Users, label: "Profissionais de alta responsabilidade" },
  { icon: Dumbbell, label: "Atletas e praticantes de alta performance" },
  { icon: Heart, label: "Pessoas que valorizam longevidade com qualidade" },
];

const services = [
  {
    icon: Scale,
    title: "Emagrecimento Estratégico",
    desc: "Redução qualificada de gordura com preservação e ganho de massa magra, eficiência metabólica e estabilidade hormonal.",
  },
  {
    icon: Sparkles,
    title: "Longevidade Inteligente",
    desc: "Otimização hormonal, controle inflamatório, preservação celular e clareza cognitiva.",
  },
  {
    icon: BrainCircuit,
    title: "Performance Física e Mental",
    desc: "Monitoramento metabólico, recuperação inteligente e prevenção de declínio funcional.",
  },
  {
    icon: Battery,
    title: "Regulação do Estresse e Energia Sustentada",
    desc: "Equilíbrio do sistema nervoso, sono otimizado e vitalidade contínua.",
  },
];

const fadeUp = {
  hidden: { opacity: 0, y: 30 },
  visible: (i: number) => ({
    opacity: 1,
    y: 0,
    transition: { duration: 0.6, delay: i * 0.1 },
  }),
};

const ParaQuem = () => {
  return (
    <section id="para-quem" className="bg-natua-green-deep py-24 lg:py-32">
      <div className="container mx-auto px-6 lg:px-12">
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-100px" }}
          className="mx-auto max-w-3xl text-center"
        >
          <motion.h2
            variants={fadeUp}
            custom={0}
            className="font-serif text-3xl font-medium text-natua-cream md:text-4xl lg:text-5xl"
          >
            Um centro para quem decide evoluir
          </motion.h2>
          <motion.p
            variants={fadeUp}
            custom={1}
            className="mt-6 font-sans text-sm font-light text-natua-cream/60"
          >
            Nosso compromisso é com resultados sustentáveis e mensuráveis.
          </motion.p>
        </motion.div>

        {/* Audience pills */}
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          className="mx-auto mt-12 flex max-w-3xl flex-wrap items-center justify-center gap-3"
        >
          {audiences.map((a, i) => (
            <motion.div
              key={a.label}
              variants={fadeUp}
              custom={i + 2}
              className="flex items-center gap-2 rounded-full border border-natua-gold/30 px-5 py-2"
            >
              <a.icon className="h-4 w-4 text-natua-gold" strokeWidth={1.5} />
              <span className="font-sans text-xs font-light tracking-wide text-natua-cream/80">{a.label}</span>
            </motion.div>
          ))}
        </motion.div>

        {/* Service cards */}
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-50px" }}
          className="mx-auto mt-16 grid max-w-5xl gap-6 sm:grid-cols-2"
        >
          {services.map((s, i) => (
            <motion.div
              key={s.title}
              variants={fadeUp}
              custom={i + 6}
              className="group rounded-sm border border-natua-gold/10 bg-natua-green/50 p-8 transition-all hover:border-natua-gold/30"
            >
              <s.icon className="mb-4 h-6 w-6 text-natua-gold" strokeWidth={1.5} />
              <h3 className="font-serif text-xl font-medium text-natua-cream">{s.title}</h3>
              <p className="mt-3 font-sans text-sm font-light leading-relaxed text-natua-cream/60">{s.desc}</p>
            </motion.div>
          ))}
        </motion.div>

        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          variants={fadeUp}
          custom={10}
          className="mt-14 text-center"
        >
          <a
            href={WHATSAPP_LINK}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-block bg-natua-gold px-8 py-4 text-xs font-bold tracking-[0.3em] uppercase text-natua-green-deep transition-all hover:bg-natua-gold-light"
          >
            Quero Evoluir com Estratégia
          </a>
        </motion.div>
      </div>
    </section>
  );
};

export default ParaQuem;
