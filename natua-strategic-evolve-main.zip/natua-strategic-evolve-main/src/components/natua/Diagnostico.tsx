import { motion } from "framer-motion";
import { Activity, Dna, FlameKindling, Brain, HeartPulse } from "lucide-react";
import { WHATSAPP_LINK } from "@/lib/constants";

const markers = [
  { icon: Activity, label: "Metabolismo e eficiência energética" },
  { icon: Dna, label: "Perfil hormonal completo" },
  { icon: FlameKindling, label: "Marcadores inflamatórios e de envelhecimento" },
  { icon: HeartPulse, label: "Performance física e neuromuscular" },
  { icon: Brain, label: "Indicadores cognitivos e regulatórios" },
];

const fadeUp = {
  hidden: { opacity: 0, y: 30 },
  visible: (i: number) => ({
    opacity: 1,
    y: 0,
    transition: { duration: 0.6, delay: i * 0.1 },
  }),
};

const Diagnostico = () => {
  return (
    <section id="diagnostico" className="bg-natua-offwhite py-24 lg:py-32">
      <div className="container mx-auto px-6 lg:px-12">
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-100px" }}
          className="mx-auto max-w-3xl text-center"
        >
          <motion.div variants={fadeUp} custom={0} className="mb-2 h-px w-12 mx-auto bg-natua-gold/50" />
          <motion.h2
            variants={fadeUp}
            custom={0}
            className="font-serif text-3xl font-medium text-primary md:text-4xl lg:text-5xl"
          >
            Excelência começa com precisão
          </motion.h2>
          <motion.p
            variants={fadeUp}
            custom={1}
            className="mt-6 font-sans text-base font-light leading-relaxed text-muted-foreground"
          >
            Cada jornada na Natua inicia com um diagnóstico aprofundado e individualizado.
          </motion.p>
        </motion.div>

        <motion.p
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          variants={fadeUp}
          custom={1}
          className="mt-4 text-center text-xs font-bold tracking-[0.3em] uppercase text-natua-gold"
        >
          Mapeamos
        </motion.p>

        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-50px" }}
          className="mx-auto mt-10 grid max-w-4xl gap-4 sm:grid-cols-2 lg:grid-cols-3"
        >
          {markers.map((m, i) => (
            <motion.div
              key={m.label}
              variants={fadeUp}
              custom={i + 2}
              className="flex items-start gap-4 rounded-sm border border-border bg-card p-5 transition-shadow hover:shadow-md"
            >
              <m.icon className="mt-0.5 h-5 w-5 shrink-0 text-natua-gold" strokeWidth={1.5} />
              <span className="font-sans text-sm font-light text-foreground">{m.label}</span>
            </motion.div>
          ))}
        </motion.div>

        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          variants={fadeUp}
          custom={7}
          className="mx-auto mt-12 max-w-2xl text-center"
        >
          <p className="font-sans text-base font-light leading-relaxed text-muted-foreground">
            A partir desses dados, desenvolvemos um plano estratégico personalizado, com monitoramento contínuo e ajustes refinados.
          </p>
          <p className="mt-4 font-serif text-base italic text-natua-green-light">
            Não trabalhamos com protocolos genéricos. Trabalhamos com precisão clínica.
          </p>
        </motion.div>

        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          variants={fadeUp}
          custom={8}
          className="mt-12 text-center"
        >
          <a
            href={WHATSAPP_LINK}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-block border-2 border-natua-gold bg-transparent px-8 py-4 text-xs font-bold tracking-[0.3em] uppercase text-natua-gold transition-all hover:bg-natua-gold hover:text-natua-green-deep"
          >
            Quero acesso ao diagnóstico Natua
          </a>
        </motion.div>
      </div>
    </section>
  );
};

export default Diagnostico;
