import { motion } from "framer-motion";
import { WHATSAPP_LINK } from "@/lib/constants";

const fadeUp = {
  hidden: { opacity: 0, y: 30 },
  visible: (i: number) => ({
    opacity: 1,
    y: 0,
    transition: { duration: 0.6, delay: i * 0.15 },
  }),
};

const CtaFinal = () => {
  return (
    <section className="relative bg-natua-green-deep py-28 lg:py-36">
      {/* Gold accent line top */}
      <div className="absolute left-1/2 top-0 h-16 w-px -translate-x-1/2 bg-gradient-to-b from-natua-gold/40 to-transparent" />

      <div className="container mx-auto px-6 lg:px-12">
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-100px" }}
          className="mx-auto max-w-2xl text-center"
        >
          <motion.h2
            variants={fadeUp}
            custom={0}
            className="font-serif text-3xl font-medium text-natua-cream md:text-4xl lg:text-5xl"
          >
            A Natua não é para todos.
          </motion.h2>
          <motion.p
            variants={fadeUp}
            custom={1}
            className="mt-8 font-sans text-base font-light leading-relaxed text-natua-cream/70"
          >
            Mantemos número limitado de membros ativos para garantir acompanhamento próximo e estratégico.
          </motion.p>
          <motion.p
            variants={fadeUp}
            custom={2}
            className="mt-4 font-sans text-base font-light leading-relaxed text-natua-cream/70"
          >
            Se você busca um novo padrão de saúde, composição corporal e longevidade, este pode ser o momento.
          </motion.p>

          <motion.div
            variants={fadeUp}
            custom={3}
            className="mt-12 flex flex-col items-center gap-4 sm:flex-row sm:justify-center"
          >
            <a
              href={WHATSAPP_LINK}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-block bg-natua-gold px-10 py-5 text-xs font-bold tracking-[0.3em] uppercase text-natua-green-deep transition-all hover:bg-natua-gold-light hover:shadow-lg"
            >
              Aplicar para Avaliação Estratégica
            </a>
            <a
              href={WHATSAPP_LINK}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-block border border-natua-cream/20 px-8 py-4 text-xs font-bold tracking-[0.3em] uppercase text-natua-cream/70 transition-all hover:border-natua-gold/50 hover:text-natua-gold"
            >
              Falar com Concierge Natua
            </a>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
};

export default CtaFinal;
